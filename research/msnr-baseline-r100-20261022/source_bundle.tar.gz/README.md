# ATOS v2.0 — frozen MSNR research baseline

**Disposition: research-only. `LIVE_EXECUTION=BLOCKED`; `FINAL_EXECUTION_AUTHORIZATION=false`.**

This folder contains a rule-based, price-action-only MSNR baseline and a public-data fetch/verify pipeline. It does not implement HMM/LSTM, broker authentication, OTP, account/balance requests, proposal/buy/sell, or live order placement. The canonical `config/LIVE_LOCK.yaml` is not part of this folder and must remain unchanged.

## Frozen model

The authoritative parameter and rule definition is `config/model_frozen.json`. Long and short setups require a prior 20-bar sweep/reclaim, a 5-bar micro-structure break within the frozen confirmation window, and a non-chop 200-SMA directional regime. Features are built vectorially from OHLC, ATR and a moving average only. The signal/ATR from row `i-1` is used to decide an entry at row `i`'s open. There is no forward-fill. Stop is 1 ATR and target is 2R; if both are hit in one OHLC bar, the stop is assumed first. Only one position may be open, and exits do not allow same-bar re-entry.

Sizing uses `(risk_fraction * normalized_equity) / (ATR * multiplier)`. This version uses multiplier 1 as a **unit-normalized linear price-PnL proxy**, not an actual verified Deriv CFD/multiplier contract. Until actual linear contract availability and all economics are independently evidenced, all simulator output is `NOT_QUALIFIED` even if its statistical thresholds pass. The requested 2.0-pip round-trip spread is converted using the captured current-API `active_symbols.pip_size`. Slippage is 5 basis points per fill, approximated at entry price for both fills; commission is excluded because no commission assumption was provided. These cost assumptions are not observed executions.

## Environment and acquisition

Use Python 3.11+ with the pinned-compatible packages in `requirements.txt`:

```bash
python -m pip install -r requirements.txt
python scripts/fetch_history.py --output-dir data/raw
```

The fetcher uses only `wss://api.derivws.com/trading/v1/options/ws/public`. It reads `active_symbols` for the current `underlying_symbol` / `pip_size` fields, preserves the exact response in `data/raw/R_100_active_symbols_response.json`, and requests R_100 candle history in three-day chunks at no less than 1.5 seconds between requests. It uses no token and no OTP. The fixed output files are `R_100_1m.csv` and `R_100_15m.csv`; manifests are adjacent. The default inclusive UTC dates are 2022-10-21 to 2024-10-21. Each chunk must be complete and exactly contiguous. A failed run leaves an explicit failure record and possibly a `.partial` file; those files are not valid data. Use a fresh output directory on retry so prior evidence is not overwritten.

Verify both timeframes independently:

```bash
python scripts/verify_history.py data/raw/R_100_1m.csv \
  --manifest data/raw/R_100_1m.manifest.json \
  --output data/raw/R_100_1m.verification.json
python scripts/verify_history.py data/raw/R_100_15m.csv \
  --manifest data/raw/R_100_15m.manifest.json \
  --output data/raw/R_100_15m.verification.json
```

Verification checks the captured `active_symbols` response/hash, endpoint and unauthenticated status, file hash, data range, row count, timestamp ordering, OHLC integrity, exact continuity, and gaps greater than 120 seconds **beyond expected candle spacing**. No missing bars are interpolated or forward-filled. The simulator accepts only the exact contiguous 1m range and a passing 1m verification report.

## Run the baseline

Run this only after official history acquisition and verification have succeeded. In a real checkout, let the script resolve `git rev-parse HEAD`. The local handoff bundle itself is not a Git checkout, so it requires the exact 40-character source commit SHA from the repository:

```bash
python scripts/run_msnr_simulator.py data/raw/R_100_1m.csv \
  --manifest data/raw/R_100_1m.manifest.json \
  --verification data/raw/R_100_1m.verification.json \
  --ledger evidence/run-01/trade_ledger.jsonl \
  --summary evidence/run-01/summary.json \
  --git-commit <EXACT_40_CHARACTER_GIT_COMMIT_SHA> \
  --allow-unverified-linear-proxy
```

`--allow-unverified-linear-proxy` deliberately produces exploratory metrics only and never changes the qualification or live-safety state. The stateful loop is Numba compiled; history is processed in 90-day segments with 250 rows of feature warm-up, ledger records are appended per segment, and dataframes/arrays are deleted with `gc.collect()` between segments. The three `HOLY_TRINITY_*` values printed at completion are the input CSV SHA-256, provided/resolved Git commit SHA, and random seed. The model is deterministic; seed 42 is recorded for audit completeness.

The kill rule is frozen: when at least one closed trade allows expectancy to be computed, **profit factor below 1.15 OR net expectancy at or below 0R** emits the exact message `KILL CRITERIA MET: Baseline alpha insufficient. Halting HMM integration.` A sample with no closed trades cannot support expectancy; the script reports the rule unevaluated and does not claim a pass.

## Local tests

```bash
python -m compileall -q scripts tests
pytest -q
```

Tests may use deterministic small OHLC fixtures to validate code paths; those fixtures are never used as market data or for strategy metrics. Empirical metrics may only be produced from verified API-fetched CSVs.
